namespace VisualNovel {
    export let sounds = {
        fightMusic: "./Audio/fightMusic.mp3",
        adventureMusic: "./Audio/adventureMusic.mp3",
        mysteriousMusic: "./Audio/mysteriousMusic.mp3",
        departureMusic: "./Audio/departureMusic.mp3"
        
    };
}