# Visual Novel Endabgame 

Autor: David Niemann  

Titel: ein unerwartetes Arbenteuer  

Tastenbelegung:  
 * M : öffnen des Menüs
 * I : öffnen des Inventars 
 * L : öffnen der Abenteuer Aufzeichnungen
 * F8: spiel Speichern 
 * F9: spiel Laden  

Link zum Spiel: [https://davidniemann.github.io/Visual_Novel_Niemann_David//Game/Game.html](https://davidniemann.github.io/Visual_Novel_Niemann_David//Game/Game.html)


Link zum programmcode: [https://github.com/DavidNiemann/Visual_Novel_Niemann_David/tree/main/Game/Source](https://github.com/DavidNiemann/Visual_Novel_Niemann_David/tree/main/Game/Source)

Link zur Konzept: [https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Kozeption/Concept_Document/Konzept_Dokument.pdf](https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Kozeption/Concept_Document/Konzept_Dokument.pdf)

Link zum Szenendiagramm: [https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Kozeption/Diagramme/StoryFinal.drawio.pdf](https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Kozeption/Diagramme/StoryFinal.drawio.pdf)

Link zur Zip: [https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Zip](https://github.com/DavidNiemann/Visual_Novel_Niemann_David/blob/main/Zip)

